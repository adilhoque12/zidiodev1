// src/App.js
import React from 'react';
import './App.css';
import SignUpForm from './components/SignUpForm';

function App() {
  return (
    <div className="app">
      <div className="background" />
      <SignUpForm />
    </div>
  );
}

export default App;
