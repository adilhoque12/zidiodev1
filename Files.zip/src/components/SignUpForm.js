// src/components/SignUpForm.js
import React from 'react';
import './SignUpForm.css';

function SignUpForm() {
  return (
    <div className="signup-container">
      <h2>Create Your Account</h2>

      <form className="signup-form">
        <input type="text" placeholder="Username" required />
        <input type="email" placeholder="Email Address" required />
        <input type="password" placeholder="Password" required />
        <input type="password" placeholder="Confirm Password" required />
        <button type="submit" className="signup-button">Sign Up</button>
      </form>

      <div className="divider">or sign up with</div>

      <div className="social-buttons">
        <button className="social google">
          <img src="google.png" alt="Google" />
          Google
        </button>
        <button className="social github">
          <img src="github.png" alt="GitHub" />
          GitHub
        </button>
      </div>

      <p className="footer-text">Already have an account? <span>Sign In</span></p>
    </div>
  );
}

export default SignUpForm;
