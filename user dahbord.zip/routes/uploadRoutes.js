const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const {
  uploadFile,
  getUserFiles,
  deleteFile
} = require('../controllers/uploadController');

router.route('/')
  .get(protect, getUserFiles)
  .post(protect, uploadFile);

router.route('/:id')
  .delete(protect, deleteFile);

module.exports = router;
