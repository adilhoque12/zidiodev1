const asyncHandler = require('express-async-handler');
const File = require('../models/File');
const User = require('../models/User');
const XLSX = require('xlsx');
const path = require('path');
const fs = require('fs');

// Configure multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});

const upload = multer({ storage });

// @desc    Upload Excel file
// @route   POST /api/upload
// @access  Private
exports.uploadFile = asyncHandler(async (req, res) => {
  upload.single('file')(req, res, async function(err) {
    if (err) {
      return res.status(400).json({ message: 'File upload failed' });
    }

    try {
      const file = req.file;
      const user = await User.findById(req.user.id);

      if (!file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      // Parse Excel file
      const workbook = XLSX.readFile(file.path);
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(worksheet);
      
      // Get column names
      const cols = [];
      for (let key in data[0]) {
        cols.push(key);
      }

      // Save file info to database
      const savedFile = await File.create({
        user: user._id,
        filename: file.originalname,
        path: file.path,
        size: file.size,
        columns: cols,
        data: data
      });

      res.status(201).json({
        id: savedFile._id,
        filename: savedFile.filename,
        columns: savedFile.columns,
        data: savedFile.data.slice(0, 20) // Return first 20 rows for preview
      });
    } catch (error) {
      console.error(error);
      if (req.file) {
        fs.unlinkSync(req.file.path); // Clean up uploaded file
      }
      res.status(500).json({ message: 'Server error' });
    }
  });
});

// @desc    Get user files
// @route   GET /api/upload
// @access  Private
exports.getUserFiles = asyncHandler(async (req, res) => {
  const files = await File.find({ user: req.user.id }).sort('-createdAt');
  res.json(files);
});

// @desc    Delete file
// @route   DELETE /api/upload/:id
// @access  Private
exports.deleteFile = asyncHandler(async (req, res) => {
  const file = await File.findById(req.params.id);

  if (!file) {
    res.status(404);
    throw new Error('File not found');
  }

  // Check user authorization
  if (file.user.toString() !== req.user.id) {
    res.status(401);
    throw new Error('User not authorized');
  }

  // Delete file from filesystem
  if (fs.existsSync(file.path)) {
    fs.unlinkSync(file.path);
  }

  await file.remove();

  res.json({ id: req.params.id });
});
