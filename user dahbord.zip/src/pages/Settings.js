// client/src/components/Settings/Settings.js
import React, { useState } from 'react';

const Settings = () => {
  const [settings, setSettings] = useState({
    theme: 'light',
    exportQuality: 'high',
    autoRefresh: false
  });
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSettings(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };
  
  return (
    <div className="settings">
      <h2>Settings</h2>
      <div className="setting-group">
        <label>Theme:</label>
        <select name="theme" value={settings.theme} onChange={handleChange}>
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </div>
      
      <div className="setting-group">
        <label>Export Quality:</label>
        <select name="exportQuality" value={settings.exportQuality} onChange={handleChange}>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
      </div>
      
      <div className="setting-group">
        <label>
          <input 
            type="checkbox" 
            name="autoRefresh" 
            checked={settings.autoRefresh} 
            onChange={handleChange}
          />
          Auto Refresh Charts
        </label>
      </div>
    </div>
  );
};

export default Settings;
