import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Line, Bar, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, registerables } from 'chart.js';
import { saveAs } from 'file-saver';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

import axios from 'axios';

// Components
import DashboardHeader from '../components/DashboardHeader';
import Card from '../components/Card';
import Loading from '../components/Loading';
import Message from '../components/Message';
import { getUserFiles } from '../features/uploads/uploadSlice';

ChartJS.register(...registerables);

const Dashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const { user } = useSelector((state) => state.auth);
  const { files, loading, error } = useSelector((state) => state.upload);
  
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedChart, setSelectedChart] = useState('line');
  const [chartData, setChartData] = useState(null);
  const [xAxis, setXAxis] = useState('');
  const [yAxis, setYAxis] = useState('');
  const [aiInsights, setAiInsights] = useState('');
  const [loadingAi, setLoadingAi] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/login');
    } else {
      dispatch(getUserFiles());
    }
  }, [user, navigate, dispatch]);

  useEffect(() => {
    if (selectedFile && xAxis && yAxis) {
      generateChart();
    }
  }, [selectedFile, xAxis, yAxis, selectedChart]);

  const generateChart = () => {
    const fileData = files.find(f => f._id === selectedFile);
    if (!fileData || !fileData.data) return;
    
    const labels = fileData.data.map(row => row[xAxis]);
    const values = fileData.data.map(row => row[yAxis]);
    
    setChartData({
      labels,
      datasets: [
        {
          label: `${yAxis} by ${xAxis}`,
          data: values,
          backgroundColor: selectedChart === 'pie' 
            ? values.map((_, i) => `hsl(${i * 360 / values.length}, 70%, 60%)`)
            : 'rgba(59, 130, 246, 0.5)',
          borderColor: 'rgba(59, 130, 246, 1)',
          borderWidth: 2,
          tension: 0.1,
          fill: selectedChart === 'line'
        }
      ]
    });
  };

  const downloadPNG = () => {
    const chartNode = document.getElementById('chart-container');
    
    html2canvas(chartNode).then(canvas => {
      canvas.toBlob(blob => {
        saveAs(blob, `${selectedChart}-chart.png`);
      });
    });
  };

  const downloadPDF = () => {
    const chartNode = document.getElementById('chart-container');
    
    html2canvas(chartNode).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('landscape');
      pdf.addImage(imgData, 'PNG', 10, 10, 280, 150);
      pdf.save(`${selectedChart}-chart.pdf`);
    });
  };

  const generateAiInsights = async () => {
    try {
      setLoadingAi(true);
      
      const fileData = files.find(f => f._id === selectedFile);
      if (!fileData) return;
      
      const { data } = await axios.post('/api/ai/insights', {
        chartType: selectedChart,
        xAxis,
        yAxis,
        data: fileData.data.slice(0, 50)
      }, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      setAiInsights(data.insights);
    } catch (err) {
      console.error(err.response.data.message);
    } finally {
      setLoadingAi(false);
    }
  };

  if (loading) {
    return <Loading />;
  }

  return (
    <DashboardContainer>
      <DashboardHeader title="Dashboard" />
      
      <DashboardContent>
        <Card>
          <h3>Your Data Files</h3>
          {error && <Message variant="danger">{error}</Message>}
          
          <SelectFiles>
            <select 
              value={selectedFile || ''} 
              onChange={(e) => setSelectedFile(e.target.value)}
            >
              <option value="">Select a file</option>
              {files.map((file) => (
                <option key={file._id} value={file._id}>
                  {file.filename} ({new Date(file.createdAt).toLocaleDateString()})
                </option>
              ))}
            </select>
          </SelectFiles>
          
          {selectedFile && (
            <SelectAxes>
              <div>
                <label>X Axis:</label>
                <select 
                  value={xAxis} 
                  onChange={(e) => setXAxis(e.target.value)}
                >
                  <option value="">Select X Axis</option>
                  {files.find(f => f._id === selectedFile)?.columns.map(col => (
                    <option key={`x-${col}`} value={col}>{col}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label>Y Axis:</label>
                <select 
                  value={yAxis} 
                  onChange={(e) => setYAxis(e.target.value)}
                >
                  <option value="">Select Y Axis</option>
                  {files.find(f => f._id === selectedFile)?.columns.map(col => (
                    <option key={`y-${col}`} value={col}>{col}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label>Chart Type:</label>
                <select 
                  value={selectedChart} 
                  onChange={(e) => setSelectedChart(e.target.value)}
                >
                  <option value="line">Line Chart</option>
                  <option value="bar">Bar Chart</option>
                  <option value="pie">Pie Chart</option>
                </select>
              </div>
            </SelectAxes>
          )}
        </Card>
        
        {chartData && (
          <>
            <Card>
              <div id="chart-container" style={{ height: '500px', width: '100%' }}>
                {selectedChart === 'line' && <Line data={chartData} />}
                {selectedChart === 'bar' && <Bar data={chartData} />}
                {selectedChart === 'pie' && <Pie data={chartData} />}
              </div>
            </Card>
            
            <Card>
              <h3>Export Options</h3>
              <ButtonGroup>
                <button onClick={downloadPNG}>Download PNG</button>
                <button onClick={downloadPDF}>Download PDF</button>
                <button onClick={generateAiInsights} disabled={loadingAi}>
                  {loadingAi ? 'Generating Insights...' : 'Generate AI Insights'}
                </button>
              </ButtonGroup>
              
              {aiInsights && (
                <AiInsights>
                  <h4>AI Insights:</h4>
                  <p>{aiInsights}</p>
                </AiInsights>
              )}
            </Card>
          </>
        )}
      </DashboardContent>
    </DashboardContainer>
  );
};

const DashboardContainer = styled.div`
  margin-left: 220px;
  padding: 2rem;
  width: calc(100% - 220px);
`;

const DashboardContent = styled.div`
  display: grid;
  gap: 2rem;
  margin-top: 1.5rem;
`;

const SelectFiles = styled.div`
  margin: 1rem 0;
  
  select {
    width: 100%;
    padding: 0.5rem;
    border-radius: 4px;
    border: 1px solid ${({ theme }) => theme.colors.border};
    background: ${({ theme }) => theme.colors.inputBg};
    color: ${({ theme }) => theme.colors.text};
  }
`;

const SelectAxes = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
  
  div {
    display: flex;
    flex-direction: column;
    
    label {
      margin-bottom: 0.5rem;
      font-size: 0.875rem;
      color: ${({ theme }) => theme.colors.textLight};
    }
    
    select {
      padding: 0.5rem;
      border-radius: 4px;
      border: 1px solid ${({ theme }) => theme.colors.border};
      background: ${({ theme }) => theme.colors.inputBg};
      color: ${({ theme }) => theme.colors.text};
    }
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 1rem;
  margin-top: 1rem;
  
  button {
    padding: 0.5rem 1rem;
    border-radius: 4px;
    background: ${({ theme }) => theme.colors.primary};
    color: white;
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;
    
    &:hover {
      background: ${({ theme }) => theme.colors.primaryDark};
    }
    
    &:disabled {
      background: ${({ theme }) => theme.colors.disabled};
      cursor: not-allowed;
    }
  }
`;

const AiInsights = styled.div`
  margin-top: 1.5rem;
  padding: 1rem;
  background: rgba(59, 130, 246, 0.1);
  border-radius: 4px;
  
  h4 {
    margin-bottom: 0.5rem;
    color: ${({ theme }) => theme.colors.primary};
  }
  
  p {
    line-height: 1.6;
  }
`;

export default Dashboard;
