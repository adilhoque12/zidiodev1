// client/src/Upload.js
import React, { useState } from 'react';
import axios from 'axios';

const FileUpload = ({ onDataLoaded }) => {
  const [file, setFile] = useState(null);
  
  const handleUpload = async () => {
    if (!file) return;
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      const res = await axios.post('/api/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      onDataLoaded(res.data.data);
    } catch (err) {
      console.error('Upload error:', err);
    }
  };
  
  return (
    <div className="file-upload">
      <input type="file" accept=".xlsx,.xls" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={handleUpload}>Upload</button>
    </div>
  );
};

export default FileUpload;
