import { configureStore } from '@reduxjs/toolkit';
import authReducer from '../features/auth/authSlice';
import uploadReducer from '../features/uploads/uploadSlice';

const store = configureStore({
  reducer: {
    auth: authReducer,
    uploads: uploadReducer,
  },
});

export default store;
