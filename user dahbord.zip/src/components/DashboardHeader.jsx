// client/src/components/DashboardHeader.jsx
import React from 'react';
import styled from 'styled-components';

const DashboardHeader = ({ title }) => {
  return (
    <HeaderContainer>
      <h1>{title}</h1>
    </HeaderContainer>
  );
};

const HeaderContainer = styled.div`
  padding: 1rem 0;
  border-bottom: 1px solid ${({ theme }) => theme.colors.border};
`;

export default DashboardHeader;
