import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../features/auth/authSlice';
import styled from 'styled-components';
import { FiLogOut, FiUser, FiBell, FiMessageSquare } from 'react-icons/fi';
import { BiSun, BiMoon } from 'react-icons/bi';

const Navbar = ({ toggleTheme, theme }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.auth);

  const logoutHandler = () => {
    dispatch(logout());
    navigate('/login');
  };

  return (
    <NavbarContainer>
      <NavLeft>
        <MobileMenuButton>
          <span></span>
          <span></span>
          <span></span>
        </MobileMenuButton>
        <SearchBar>
          <input type="text" placeholder="Search..." />
        </SearchBar>
      </NavLeft>

      <NavRight>
        <ThemeToggle onClick={toggleTheme}>
          {theme === 'light' ? <BiMoon /> : <BiSun />}
        </ThemeToggle>
        
        <NotificationIcon>
          <FiBell />
          <NotificationBadge>3</NotificationBadge>
        </NotificationIcon>
        
        <MessageIcon>
          <FiMessageSquare />
          <NotificationBadge>5</NotificationBadge>
        </MessageIcon>
        
        <UserDropdown>
          <UserProfile>
            {user?.name}
            <ProfileImage>
              <img src={`https://ui-avatars.com/api/?name=${user?.name}&background=3b82f6&color=fff`} 
                   alt={`Profile of ${user?.name}`} />
            </ProfileImage>
          </UserProfile>
          <DropdownMenu>
            <DropdownItem as={Link} to="/profile">
              <FiUser /> Profile
            </DropdownItem>
            <DropdownItem onClick={logoutHandler}>
              <FiLogOut /> Logout
            </DropdownItem>
          </DropdownMenu>
        </UserDropdown>
      </NavRight>
    </NavbarContainer>
  );
};

const NavbarContainer = styled.nav`
  height: 70px;
  background: ${({ theme }) => theme.navbar.bg};
  color: ${({ theme }) => theme.navbar.text};
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 2rem;
  position: fixed;
  top: 0;
  right: 0;
  left: 220px;
  z-index: 90;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;

  @media (max-width: 768px) {
    left: 0;
  }
`;

const NavLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 1.5rem;
`;

const MobileMenuButton = styled.button`
  display: none;
  flex-direction: column;
  justify-content: space-between;
  width: 24px;
  height: 18px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  
  span {
    height: 2px;
    width: 100%;
    background: ${({ theme }) => theme.navbar.text};
    border-radius: 2px;
  }

  @media (max-width: 768px) {
    display: flex;
  }
`;

const SearchBar = styled.div`
  position: relative;
  
  input {
    width: 300px;
    padding: 0.5rem 1rem;
    padding-left: 2.5rem;
    border-radius: 20px;
    border: none;
    background: ${({ theme }) => theme.navbar.searchBg};
    color: ${({ theme }) => theme.colors.text};
    transition: all 0.3s ease;
    
    &:focus {
      outline: none;
      box-shadow: 0 0 0 2px ${({ theme }) => theme.colors.primaryLight};
    }

    @media (max-width: 768px) {
      width: 200px;
    }
  }

  &:before {
    content: '🔍';
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
  }
`;

const NavRight = styled.div`
  display: flex;
  align-items: center;
  gap: 1.5rem;
`;

const NotificationIcon = styled.div`
  position: relative;
  cursor: pointer;
  font-size: 1.25rem;
  color: ${({ theme }) => theme.navbar.icon};
  
  &:hover {
    color: ${({ theme }) => theme.colors.primary};
  }
`;

const MessageIcon = styled(NotificationIcon)`
  /* Inherits styles from NotificationIcon */
`;

const NotificationBadge = styled.span`
  position: absolute;
  top: -5px;
  right: -5px;
  background: ${({ theme }) => theme.colors.danger};
  color: white;
  border-radius: 50%;
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.6rem;
  font-weight: bold;
`;

const ThemeToggle = styled.button`
  background: transparent;
  border: none;
  font-size: 1.25rem;
  color: ${({ theme }) => theme.navbar.icon};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  
  &:hover {
    color: ${({ theme }) => theme.colors.primary};
  }
`;

const UserDropdown = styled.div`
  position: relative;
  cursor: pointer;
  
  &:hover {
    div:last-child {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }
  }
`;

const UserProfile = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.5rem;
  border-radius: 30px;
  transition: all 0.3s ease;
  font-weight: 500;
  
  &:hover {
    background: ${({ theme }) => theme.navbar.hoverBg};
  }
`;

const ProfileImage = styled.div`
  width: 36px;
  height: 36px;
  border-radius: 50%;
  overflow: hidden;
  background: ${({ theme }) => theme.colors.primaryLight};
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const DropdownMenu = styled.div`
  position: absolute;
  right: 0;
  top: calc(100% + 10px);
  background: ${({ theme }) => theme.navbar.dropdownBg};
  min-width: 200px;
  border-radius: 8px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  padding: 0.5rem 0;
  opacity: 0;
  visibility: hidden;
  transform: translateY(10px);
  transition: all 0.3s ease;
  z-index: 100;
`;

const DropdownItem = styled.div`
  padding: 0.75rem 1.5rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  color: ${({ theme }) => theme.navbar.text};
  
  &:hover {
    background: ${({ theme }) => theme.navbar.hoverBg};
    color: ${({ theme }) => theme.colors.primary};
  }
  
  svg {
    font-size: 1.1rem;
  }
`;

export default Navbar;
