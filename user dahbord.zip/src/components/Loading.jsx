import React from 'react';
import styled from 'styled-components';

const Loading = () => {
  return (
    <LoadingContainer>
      <LoadingSpinner />
    </LoadingContainer>
  );
};

const LoadingContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh; /* Full height of the viewport */
`;

const LoadingSpinner = styled.div`
  border: 8px solid rgba(255, 255, 255, 0.1);
  border-left-color: #3b82f6; /* Blue color for the spinner */
  border-radius: 50%;
  width: 60px; /* Width of the spinner */
  height: 60px; /* Height of the spinner */
  animation: spin 1s linear infinite; /* Animation for spinning effect */

  @keyframes spin {
    0% {
      transform: rotate(0deg); /* Start rotation */
    }
    100% {
      transform: rotate(360deg); /* End rotation */
    }
  }
`;

export default Loading;
