import React from 'react';
import { NavLink } from 'react-router-dom';
import styled from 'styled-components';
import { FiHome, FiUpload, FiActivity, FiSettings } from 'react-icons/fi';
import { RiBrainLine } from 'react-icons/ri';

const Sidebar = ({ toggleTheme }) => {
  return (
    <SidebarContainer>
      <LogoContainer>
        <Logo>Excel Analytics</Logo>
      </LogoContainer>
      <NavItems>
        <StyledNavLink to="/" exact="true">
          <FiHome />
          <span>Dashboard</span>
        </StyledNavLink>
        <StyledNavLink to="/upload">
          <FiUpload />
          <span>Upload Data</span>
        </StyledNavLink>
        <StyledNavLink to="/ai-tools">
          <RiBrainLine />
          <span>AI Tools</span>
        </StyledNavLink>
      </NavItems>
      <BottomNav>
        <StyledNavLink to="/settings">
          <FiSettings />
          <span>Settings</span>
        </StyledNavLink>
        <ThemeButton onClick={toggleTheme}>
          <FiActivity />
        </ThemeButton>
      </BottomNav>
    </SidebarContainer>
  );
};

const SidebarContainer = styled.div`
  width: 220px;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  background: ${({ theme }) => theme.sidebar.bg};
  color: ${({ theme }) => theme.sidebar.text};
  display: flex;
  flex-direction: column;
  padding: 2rem 0;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
  z-index: 100;
`;

const LogoContainer = styled.div`
  padding: 0 1rem 2rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
`;

const Logo = styled.h2`
  font-size: 1.5rem;
  font-weight: 700;
  color: ${({ theme }) => theme.sidebar.logo};
`;

const NavItems = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 1rem 0;
`;

const StyledNavLink = styled(NavLink)`
  display: flex;
  align-items: center;
  padding: 0.8rem 1.5rem;
  margin: 0.25rem 0;
  color: inherit;
  text-decoration: none;
  transition: all 0.2s ease;

  &:hover {
    background: ${({ theme }) => theme.sidebar.hoverBg};
  }

  svg {
    margin-right: 1rem;
    font-size: 1.2rem;
  }

  &.active {
    background: ${({ theme }) => theme.sidebar.activeBg};
    color: ${({ theme }) => theme.sidebar.activeText};
  }
`;

const BottomNav = styled.div`
  display: flex;
  flex-direction: column;
`;

const ThemeButton = styled.button`
  margin: 1rem;
  padding: 0.8rem;
  background: ${({ theme }) => theme.sidebar.themeButtonBg};
  color: ${({ theme }) => theme.sidebar.themeButtonText};
  border: none;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;

  &:hover {
    background: ${({ theme }) => theme.sidebar.themeButtonHoverBg};
  }
`;

export default Sidebar;
