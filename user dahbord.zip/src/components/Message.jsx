// client/src/components/Message.jsx
import React from 'react';
import styled from 'styled-components';

const Message = ({ variant, children }) => {
  return <MessageContainer variant={variant}>{children}</MessageContainer>;
};

const MessageContainer = styled.div`
  padding: 1rem;
  border-radius: 4px;
  margin: 1rem 0;
  background: ${({ variant }) => (variant === 'danger' ? '#f8d7da' : '#d1e7dd')};
  color: ${({ variant }) => (variant === 'danger' ? '#721c24' : '#0f5132')};
`;

export default Message;
