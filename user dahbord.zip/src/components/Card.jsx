// client/src/components/Card.jsx
import React from 'react';
import styled from 'styled-components';

const Card = ({ children }) => {
  return <CardContainer>{children}</CardContainer>;
};

const CardContainer = styled.div`
  background: ${({ theme }) => theme.card.bg};
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
`;

export default Card;
