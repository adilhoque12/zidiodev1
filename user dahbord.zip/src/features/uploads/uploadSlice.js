// client/src/features/uploads/uploadSlice.js
import { createSlice } from '@reduxjs/toolkit';

const uploadSlice = createSlice({
  name: 'uploads',
  initialState: {
    files: [],
    loading: false,
    error: null,
  },
  reducers: {
    uploadRequest: (state) => {
      state.loading = true;
      state.error = null;
    },
    uploadSuccess: (state, action) => {
      state.files.push(action.payload);
      state.loading = false;
    },
    uploadFailure: (state, action) => {
      state.loading = false;
      state.error = action.payload;
    },
    getUserFiles: (state, action) => {
      state.files = action.payload;
      state.loading = false;
    },
  },
});

export const { uploadRequest, uploadSuccess, uploadFailure, getUserFiles } = uploadSlice.actions;
export default uploadSlice.reducer;
