export const lightTheme = {
  sidebar: {
    bg: '#ffffff',
    text: '#000000',
    hoverBg: '#f0f0f0',
    activeBg: '#e0e0e0',
    activeText: '#3b82f6',
    themeButtonBg: '#f0f0f0',
    themeButtonText: '#000000',
    themeButtonHoverBg: '#e0e0e0',
  },
  navbar: {
    bg: '#ffffff',
    text: '#000000',
    icon: '#000000',
    hoverBg: '#f0f0f0',
    dropdownBg: '#ffffff',
  },
  card: {
    bg: '#ffffff',
  },
  colors: {
    primary: '#3b82f6',
    primaryLight: '#60a5fa',
    border: '#e0e0e0',
    text: '#000000',
    textLight: '#555555',
    danger: '#dc3545',
  },
};

export const darkTheme = {
  sidebar: {
    bg: '#1f2937',
    text: '#ffffff',
    hoverBg: '#374151',
    activeBg: '#4b5563',
    activeText: '#3b82f6',
    themeButtonBg: '#374151',
    themeButtonText: '#ffffff',
    themeButtonHoverBg: '#4b5563',
  },
  navbar: {
    bg: '#1f2937',
    text: '#ffffff',
    icon: '#ffffff',
    hoverBg: '#374151',
    dropdownBg: '#1f2937',
  },
  card: {
    bg: '#374151',
  },
  colors: {
    primary: '#3b82f6',
    primaryLight: '#60a5fa',
    border: '#4b5563',
    text: '#ffffff',
    textLight: '#d1d5db',
    danger: '#dc3545',
  },
};
